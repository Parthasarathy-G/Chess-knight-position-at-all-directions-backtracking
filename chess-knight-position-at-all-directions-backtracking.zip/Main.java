import java.util.*;
class KnightPosition {
    int x, y, dist;

    public KnightPosition(int x, int y, int dist) {
        this.x = x;
        this.y = y;
        this.dist = dist;
    }
}

public class chess{
    public static int minimumSteps(int N, int startX, int startY, int targetX, int targetY) {
        int[] dx = {-2, -1, 1, 2, -2, -1, 1, 2};
        int[] dy = {-1, -2, -2, -1, 1, 2, 2, 1};
        boolean[][] visited = new boolean[N][N];
        visited[startX - 1][startY - 1] = true;
        Queue<KnightPosition> queue = new LinkedList<>();
        queue.add(new KnightPosition(startX - 1, startY - 1, 0));

        while (!queue.isEmpty()) {
            KnightPosition currentPosition = queue.poll();
            if (currentPosition.x == targetX - 1 && currentPosition.y == targetY - 1) {
                return currentPosition.dist;
            }
            for (int i = 0; i < 8; i++) {
                int newX = currentPosition.x + dx[i];
                int newY = currentPosition.y + dy[i];
                if (newX >= 0 && newX < N && newY >= 0 && newY < N && !visited[newX][newY]) {
                    visited[newX][newY] = true;
                    queue.add(new KnightPosition(newX, newY, currentPosition.dist + 1));
                }
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner ps = new Scanner(System.in);
        int startX = ps.nextInt(),startY = ps.nextInt(),targetX = ps.nextInt(),targetY = ps.nextInt(),a[] = new int[4];
        a[0] = startX;
        a[1] = startY;
        a[2] = targetX;
        a[3] = targetY;
        Arrays.sort(a);
        int N = a[3];
        int minimumSteps = minimumSteps(N, startX, startY, targetX, targetY);
        System.out.println(minimumSteps);
    }
}
